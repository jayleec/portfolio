package models

type Project struct {
	Id 		int
	Title 		string
	Git 		string
	Language 	string
	Images 		string
	Video 		string
	Deploy 		string
	Details 	string
	Back 		string
}