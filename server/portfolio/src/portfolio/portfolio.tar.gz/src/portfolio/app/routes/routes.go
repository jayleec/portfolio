// GENERATED CODE - DO NOT EDIT
package routes

import "github.com/revel/revel"


type tGorpController struct {}
var GorpController tGorpController


func (_ tGorpController) Begin(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("GorpController.Begin", args).Url
}

func (_ tGorpController) Commit(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("GorpController.Commit", args).Url
}

func (_ tGorpController) Rollback(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("GorpController.Rollback", args).Url
}


type tTestRunner struct {}
var TestRunner tTestRunner


func (_ tTestRunner) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("TestRunner.Index", args).Url
}

func (_ tTestRunner) Suite(
		suite string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "suite", suite)
	return revel.MainRouter.Reverse("TestRunner.Suite", args).Url
}

func (_ tTestRunner) Run(
		suite string,
		test string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "suite", suite)
	revel.Unbind(args, "test", test)
	return revel.MainRouter.Reverse("TestRunner.Run", args).Url
}

func (_ tTestRunner) List(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("TestRunner.List", args).Url
}


type tStatic struct {}
var Static tStatic


func (_ tStatic) Serve(
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.Serve", args).Url
}

func (_ tStatic) ServeModule(
		moduleName string,
		prefix string,
		filepath string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "moduleName", moduleName)
	revel.Unbind(args, "prefix", prefix)
	revel.Unbind(args, "filepath", filepath)
	return revel.MainRouter.Reverse("Static.ServeModule", args).Url
}


type tApp struct {}
var App tApp


func (_ tApp) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Index", args).Url
}

func (_ tApp) Articles(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Articles", args).Url
}

func (_ tApp) Awards(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Awards", args).Url
}

func (_ tApp) Golang(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("App.Golang", args).Url
}


type tProjects struct {}
var Projects tProjects


func (_ tProjects) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Projects.Index", args).Url
}

func (_ tProjects) Project(
		title string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "title", title)
	return revel.MainRouter.Reverse("Projects.Project", args).Url
}


type tArticles struct {}
var Articles tArticles


func (_ tArticles) Index(
		) string {
	args := make(map[string]string)
	
	return revel.MainRouter.Reverse("Articles.Index", args).Url
}

func (_ tArticles) Article(
		address string,
		) string {
	args := make(map[string]string)
	
	revel.Unbind(args, "address", address)
	return revel.MainRouter.Reverse("Articles.Article", args).Url
}


