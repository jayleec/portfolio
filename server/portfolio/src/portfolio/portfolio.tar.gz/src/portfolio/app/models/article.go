package models

type Article struct {
	ArticleId 	int
	Address 	string
	Title 		string
	Url 		string
}